/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monprojetig;

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author kahina
 */
public class Arme {
    private Rectangle rect=new Rectangle(0,0,10,50);
    private Circle circle=new Circle(0,0,5,Color.BLACK);
    public Arme(JeuObject joueur){
        rect.setTranslateX(joueur.getnoeudGraph().getTranslateX()+40);
        rect.setFill(Color.GREY);
        rect.setTranslateY(joueur.getnoeudGraph().getTranslateY()-5);
        tirer();
    }

    private void tirer() {
        circle.setTranslateX(rect.getTranslateX()+5);
        circle.setTranslateY(rect.getTranslateY()+20);
    }

    public Rectangle getRect() {
        return rect;
    }
    public void attachToPlayer(Joueur j){
        rect.setTranslateX(j.getnoeudGraph().getTranslateX()+40);
        rect.setTranslateY(j.getnoeudGraph().getTranslateY()-5);
        tirer();
    }

    public Circle getCircle() {
        return circle;
    }
    public double getRotate1(){
        return rect.getRotate()-90;
    }
    public void rotateRight(){
       rect.setRotate(rect.getRotate()+5);
    }
     public void rotateLeft(){
       rect.setRotate(rect.getRotate()-5);
    }
    
}
