/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monprojetig;

import javafx.geometry.Point2D;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

/**
 *
 * @author kahina
 */

public class Balle extends JeuObject {
    
    private Point2D direction=new Point2D(0,0);
    public Balle(Arme arme){
        noeudGraph=new Circle(0,0,5,Color.RED);
        noeudGraph.setTranslateX(arme.getCircle().getTranslateX());
        noeudGraph.setTranslateY(arme.getCircle().getTranslateY());
        upDateDirection(arme.getRotate1());
      
    }
    
    //mise à jour de direction de balle
    private void  upDateDirection(double rotation){
       Point2D p;
       double x=Math.cos(Math.toRadians(rotation));
       double y=Math.sin(Math.toRadians(rotation));
       p=new Point2D(x,y);
       direction=p;
    }
    public void upDate(){
        noeudGraph.setTranslateX(noeudGraph.getTranslateX()+direction.getX());
        noeudGraph.setTranslateY(noeudGraph.getTranslateY()+direction.getY());
    }
    
}
