/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monprojetig;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import static java.lang.Math.random;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.AnimationTimer;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import static javafx.print.PrintColor.COLOR;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Glow;
import javafx.scene.effect.MotionBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;

/**
 *
 * @author kahina
 */
public class JeuController implements Initializable {
  private  Zone z2=new Zone(50,450,450,500); 
  private  Zone z1 =new Zone(0,0,400,300); 
  private  Joueur j=new Joueur(z2);
     
  private List<Monstre> monstresF=new ArrayList<>();
  private List<Monstre> monstresM=new ArrayList<>(); 
  private List<Balle> balles=new ArrayList<>(); 
  Arme arme =new Arme(j);
 
  int n=0;
      @FXML
    private BorderPane bp;
        @FXML
    private Label label;
    @FXML
    private Pane pane;
     @FXML
    private Button btn;
      @FXML
    private Button pause;
        @FXML
    private Button start;
          @FXML
    private Button restart;
    @FXML
    private Text log;
   
     URL url;
     int score=0;
     Boolean x=true;
    @FXML
    private void handleButtonAction(ActionEvent event) throws FileNotFoundException {
  
     
       
    }
    @FXML
    private void handleButtonAction1(ActionEvent event1) throws FileNotFoundException {
     generateMonstre();
     pane.getChildren().add(j.getnoeudGraph());
     pane.getChildren().add(arme.getRect());
     pane.getChildren().add(arme.getCircle());
     pane.setOnKeyPressed(event);
     animation.start();
     start.disableProperty().setValue(Boolean.TRUE);
       
    }
     @FXML
    private void handleButtonAction2(ActionEvent event) throws FileNotFoundException {
  
     animation.stop();
       
    }
      @FXML
    private void handleButtonAction3(ActionEvent event) throws FileNotFoundException {
  
     animation.start();
     
       
    }
    
    
     public void setLogin(String login){
        log.setText(login);
    }
   
    private void generateMonstre(){
      Random random = new Random(System.nanoTime());
      for(int i=0;i<4;i++){
       Monstre mons =new Monstre('F',z1);
       Monstre mon=new Monstre('M',z1);
       pane.getChildren().add(mons.getnoeudGraph());
       pane.getChildren().add(mon.getnoeudGraph());
       monstresF.add(mons);
       monstresM.add(mon); 
        }}
   //event  handler
    EventHandler<KeyEvent> event=new EventHandler<KeyEvent>(){
      @Override
      public void handle(KeyEvent event) {
          if(event.getCode()==KeyCode.X){
              arme.rotateLeft();
              
          }
          if(event.getCode()==KeyCode.W){
              arme.rotateRight();
              
          }
          if(event.getCode()==KeyCode.ENTER){
             Balle balle=new Balle(arme);
             pane.getChildren().add(balle.getnoeudGraph());
             balles.add(balle); 
              
          }
          if(event.getCode()==KeyCode.LEFT){
            j.getnoeudGraph().setTranslateX(j.getnoeudGraph().getTranslateX()-5);
            arme.attachToPlayer(j);
          
          }
          if(event.getCode()==KeyCode.RIGHT){
              j.getnoeudGraph().setTranslateX(j.getnoeudGraph().getTranslateX()+5);
              arme.attachToPlayer(j);
  
          }
           if(event.getCode()==KeyCode.UP){
              j.getnoeudGraph().setTranslateY(j.getnoeudGraph().getTranslateY()-5);
              arme.attachToPlayer(j);
             
            if(event.getCode()==KeyCode.DOWN){
              j.getnoeudGraph().setTranslateY(j.getnoeudGraph().getTranslateY()+5);
              arme.attachToPlayer(j);
             
          }
          }
      }
  };
   AnimationTimer animation = new AnimationTimer() {
        @Override
        public void handle(long now) {
           refreshContent();
            for(Monstre mons:monstresF){   
                    mons.move();
                   
                
            }
            for(Monstre mon:monstresM){
              mon.move();
            } 
            
           
        }
    } ;
      private void refreshContent() {
       //parcourrir la position de balle
        
       for(Balle balle:balles){
           balle.upDate();
       }
       for(Balle balle:balles){
           for(Monstre mons:monstresF){
               if (balle.touch(mons)){
                   FadeTransition fadein = new FadeTransition(Duration.millis(500), mons.getnoeudGraph());
                       fadein.setFromValue(0.0);
                        fadein.setToValue(1.0);
                        fadein.play();

                   pane.getChildren().removeAll(balle.getnoeudGraph(),mons.getnoeudGraph());
                   score=score+10;
                   balle.setVivant(false);
                   mons.setVivant(false);
                   btn.setText("score"+" "+score);
                   
               }
           }
       }
          for(Balle balle:balles){
           for(Monstre mon:monstresM){
               if (balle.touch(mon)){
                    FadeTransition fadein = new FadeTransition(Duration.millis(500), mon.getnoeudGraph());
                       fadein.setFromValue(0.0);
                        fadein.setToValue(1.0);
                        fadein.play();
                   pane.getChildren().removeAll(balle.getnoeudGraph(),mon.getnoeudGraph());
                   score=score+10;
                    balle.setVivant(false);
                    mon.setVivant(false);
                     btn.setText("score"+" "+score);
               }
           }
       }
           
           for(Monstre mon:monstresM){
               if (mon.touch(j)){
                    FadeTransition fadein = new FadeTransition(Duration.millis(500), j.getnoeudGraph());
                       fadein.setFromValue(0.0);
                        fadein.setToValue(1.0);
                        fadein.play();
                   pane.getChildren().removeAll(j.getnoeudGraph(),arme.getRect(),arme.getCircle());
                     btn.setText("you loose !!");
                     animation.stop();
               }
           
       }
            for(Monstre mons:monstresF){
               if (mons.touch(j)){
                   pane.getChildren().removeAll(j.getnoeudGraph(),arme.getRect(),arme.getCircle());
                     btn.setText("you loose !!");
                      animation.stop();
               }
           
       }
           
       monstresM.removeIf(JeuObject::estMort);
       monstresF.removeIf(JeuObject::estMort);
       balles.removeIf(JeuObject::estMort);    
      }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
    
    start.setText("START"); 
    restart.setText("RESTART"); 
    btn.setText("score"+" "+score);
    pause.setText("PAUSE");
    label.setTextFill(Color.AQUA);
    
    // Aréne ar=new Aréne(); 
    // pane.getChildren().add(ar.getnoeudGraph());
    
     
    
     
    
    }    
    
   }
