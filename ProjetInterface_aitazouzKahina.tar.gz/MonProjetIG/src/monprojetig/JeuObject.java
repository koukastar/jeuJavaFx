/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monprojetig;
import java.util.Random;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.layout.Region;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
/**
 *
 * @author kahina
 */
public class JeuObject {
    protected Node noeudGraph;
    private boolean vivant=true;
    private Point2D direction=new Point2D(0,0);
    public void setDirection(Point2D direction) {
        this.direction = direction;
    }

    public void setVivant(boolean vivant) {
        this.vivant = vivant;
    }
    public boolean estVivant(){
            return vivant;
    }
      public boolean estMort(){
            return !vivant;
    }
    public Node getnoeudGraph(){
        return noeudGraph;
    }
      public void setNoeudGraph(Node n){
       noeudGraph =n;
    }
      //pour tuer les monstres et aussi généré des enfants
    public boolean touch(JeuObject object){
        return noeudGraph.getBoundsInParent().intersects(object.getnoeudGraph().getBoundsInParent());
    }
     public void move (){
          
          noeudGraph.setTranslateY(noeudGraph.getTranslateY()+0.02);
      
              if(noeudGraph.getTranslateY()>500){
                  noeudGraph.setTranslateY(noeudGraph.getTranslateY()-0.02);
                  noeudGraph.setTranslateX(noeudGraph.getTranslateX()+0.02);
              
              }
              if (noeudGraph.getTranslateX()>600){
                    noeudGraph.setTranslateY(noeudGraph.getTranslateY()+0.02);
                  noeudGraph.setTranslateX(noeudGraph.getTranslateX()-0.02);
                 
              }
              if (noeudGraph.getTranslateX()<100){
                    noeudGraph.setTranslateY(noeudGraph.getTranslateX()+0.02);
                   noeudGraph.setTranslateX(noeudGraph.getTranslateY()-0.02);
              }
               if (noeudGraph.getTranslateY()<100){
                    noeudGraph.setTranslateY(noeudGraph.getTranslateY()+0.02);
                   noeudGraph.setTranslateX(noeudGraph.getTranslateX()-0.02);
              }
              }
     
       
     }
    
          
   
                  
    
