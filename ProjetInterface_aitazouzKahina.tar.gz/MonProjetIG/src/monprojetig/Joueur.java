/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monprojetig;
import java.io.InputStream;
import java.net.URL;
import java.util.Random;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import static javafx.scene.input.DataFormat.URL;


/**
 *extends JeuObject
 * @author kahina
 */
public class Joueur extends JeuObject{
   
    public Joueur(Zone z){
     Random random = new Random(System.nanoTime());
        URL url = getClass().getResource("ImageJeux/solder.png");
        Image per = new Image(url.toString());
        noeudGraph=new ImageView(per);
        ((ImageView)noeudGraph).setX(0);
        ((ImageView)noeudGraph).setY(0);
        double x=z.getX1()+(z.getX2()-z.getX1())*Math.random();
        double y=z.getY1()+(z.getY2()-z.getY1())*Math.random();
        noeudGraph.setTranslateX(x);
        noeudGraph.setTranslateY(y);
     }
    
}
