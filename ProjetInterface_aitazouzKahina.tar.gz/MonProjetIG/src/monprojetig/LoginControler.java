package monprojetig;



import java.net.URL;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;

public class LoginControler {
    @FXML
    private TextField login;
    @FXML
    private PasswordField password;
     @FXML
    private StackPane gp;
    private SimpleBooleanProperty isLogin
            = new SimpleBooleanProperty(false);

    /**
     * Initializes the controller class.
     */
    public ReadOnlyBooleanProperty isLoginProperty() {
        return isLogin;
    }

    public boolean getIsLogin() {
        return isLogin.get();
    }

    @FXML
    public void initialize() {
       
     
    }

    @FXML
    void login(ActionEvent event) {
        /* verifier login et password et si tout ok alors
         */
        isLogin.set(true);
    }

    public String getLogin(){
        return login.getText();
    }
  
}
