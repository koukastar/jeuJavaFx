package monprojetig;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.StackPane;

import java.io.IOException;

public class MainControler {
    @FXML
    private StackPane stackPane;
     
    private Parent loginPane, jeuPane;
    private LoginControler loginController;
    private JeuController jeuController;

    @FXML
    public void initialize() {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass()
                .getResource("LOGIN.fxml"));

        try {
            loginPane = loader.load();
        } catch (IOException e) {
            System.err.println("load login.fxml exception");
            e.printStackTrace();
            System.exit(0);
        }

        if (loginPane == null) {
            System.err.println("loginPane null");
            System.exit(0);
        }

        if (stackPane == null) {
            System.err.println("stackPane null");
            System.exit(0);
        }

        stackPane.getChildren().add(loginPane);
        loginController = loader.getController();

        loginController.isLoginProperty()
                .addListener((observable, oldVal, newVal) -> {
                    System.out.println(loginController.getLogin());
                    FXMLLoader loader2 = new FXMLLoader();
                    loader2.setLocation(getClass()
                            .getResource("FXMLDocument.fxml"));

                    try {
                        jeuPane = loader2.load();
                    } catch (IOException e) {
                        System.err.println("Another load failed IOException");
                        e.printStackTrace();
                        System.exit(0);
                    }
                    if (jeuPane == null) {
                        System.err.println("Another load failed null");
                        System.exit(0);
                    }
                    jeuController = loader2.getController();
                    jeuController.setLogin(loginController.getLogin());
                    

                    stackPane.getChildren().add(jeuPane);
                    stackPane.getChildren().remove(loginPane);

                    /* oublier login */
                    loginPane = null;
                    loginController = null;

                });

    }
}
