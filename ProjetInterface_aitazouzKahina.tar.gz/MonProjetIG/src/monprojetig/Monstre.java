/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monprojetig;

import static java.lang.Math.random;
import static java.lang.StrictMath.random;
import java.net.URL;
import java.util.Random;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author kahina
 */
public class Monstre extends JeuObject  {
      double x,y;
    public Monstre(char sexe,Zone z){
        
        Random random = new Random(System.nanoTime());
        URL url = getClass().getResource("ImageJeux/fmo.png");
        Image femme = new Image(url.toString());
        URL url1 = getClass().getResource("ImageJeux/hoMo.png");
        Image homme = new Image(url1.toString());
        Image image = ( sexe== 'F')? femme : homme;
         noeudGraph=new ImageView(image);
        ((ImageView)noeudGraph).setX(0);
        ((ImageView)noeudGraph).setY(0);
        
         x=z.getX1()+(z.getX2()-z.getX1())*Math.random();
         y=z.getY1()+(z.getY2()-z.getY1())*Math.random();
          noeudGraph.setTranslateX(x);
          noeudGraph.setTranslateY(y);
   
}
}

