/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monprojetig;

import java.net.URL;
import java.util.Random;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author kahina
 */
public class Pistol extends JeuObject  {
    public  Pistol(){
        Random random = new Random(System.nanoTime());
        URL url = getClass().getResource("ImageJeux/solder.png");
        Image pis = new Image(url.toString());
        noeudGraph=new ImageView(pis);
       ((ImageView)noeudGraph).setX(100);
       ((ImageView)noeudGraph).setY(100);
    }
}
